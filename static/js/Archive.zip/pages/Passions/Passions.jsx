import Text from '../../components/Text/Text';
import { HEADER } from '../../components/constants';

/**
 * <Passions />
 *  Will be formatted exactly like Portfolio*
 */

function Passions() {
  return <Text type={HEADER}>Passions</Text>;
}

export default Passions;
